var char = "*";

console.log("Diagonal con N=20");

for (let index = 0; index < 20; index++) {
    console.log(char.padStart(i));
    
}