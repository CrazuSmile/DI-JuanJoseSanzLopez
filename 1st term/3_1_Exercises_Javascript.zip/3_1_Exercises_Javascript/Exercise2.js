var char = "*";

console.log("Diagonal inversa con N=20");

for (let index = 20; index > 0; index--) {
    console.log(char.padStart(i));
    
}