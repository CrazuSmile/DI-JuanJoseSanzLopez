var char = "*";

console.log("Triangulo inverso con N=20");


for (let i = 0; i <= 20; i++) {
    console.log(char.repeat(i));
}