var char = "*";

console.log("Triangulo inverso con N=20");


for (let i = 20; i >= 0; i--) {
    console.log(char.repeat(i));
}
